// Copyright 2023 Anjheos (@Anjheos)
// SPDX-License-Identifier: GPL-2.0-or-later

#pragma once

#define NO_MUSIC_MODE
