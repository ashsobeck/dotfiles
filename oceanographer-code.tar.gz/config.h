// Copyright 2023 Anjheos (@Anjheos)
// SPDX-License-Identifier: GPL-2.0-or-later

#pragma once

// Audio Settings
#ifdef AUDIO_ENABLE

#define AUDIO_PIN C6

#define AUDIO_INIT_DELAY

#endif
